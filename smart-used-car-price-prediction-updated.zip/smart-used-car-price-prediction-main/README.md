# 🚗 Smart Used Car Price Prediction

![Python](https://img.shields.io/badge/Python-3.11-blue?logo=python)
![Flask](https://img.shields.io/badge/Flask-3.1-black?logo=flask)
![scikit-learn](https://img.shields.io/badge/scikit--learn-1.8-orange?logo=scikitlearn)

A machine learning web app that estimates the fair market value of a used car in India and tells you whether a seller's asking price is fair, too high, or suspiciously low.

**🔗 Live demo:** <!-- TODO: paste your deployed URL here -->

<!-- TODO: add a screenshot, e.g. ![App screenshot](assets/screenshot.png) -->

---

## 📌 Problem

Used car prices depend on brand, model, age, mileage, fuel type, and location, so it's hard to tell whether a listing is fairly priced. This project learns those patterns from ~7,400 real listings and turns them into an instant valuation with an honest error range.

## ✨ Features

- **Price estimate with an 80% range** built from the model's real errors on unseen test data
- **Deal verdict**: enter the seller's asking price to get *Underpriced / Fair / Overpriced*
- **Similar real listings** from the dataset, matched on age and kilometers
- **Price-by-year chart** showing how value changes with age
- **Reliability warnings** when the car, brand, or city wasn't in the training data
- EMI calculator and downloadable PDF valuation report
- Dropdowns populated from the training data, so every input is something the model has actually seen

## 🛠️ Tech Stack

| Layer | Tools |
|---|---|
| Data & modelling | pandas, NumPy, scikit-learn |
| Model | `HistGradientBoostingRegressor` on log-price, inside a single scikit-learn `Pipeline` |
| Web app | Flask, Chart.js, jsPDF |
| Deployment | Gunicorn |

## 📂 Project Structure

```
smart-used-car-price-prediction/
├── app/
│   ├── app.py                  # Flask app: validation, prediction, JSON API
│   └── templates/index.html    # Frontend
├── data/
│   └── Used_Car_Price_Prediction.csv   # Raw listings (Feb 2019 – May 2021)
├── models/
│   ├── car_price_pipeline.joblib       # Preprocessing + model in one object
│   └── model_metadata.json             # Metrics, error band, dropdown options
├── notebooks/
│   └── 01_EDA_Used_Car.ipynb   # Exploratory analysis
├── train.py                    # Reproducible training script
└── requirements.txt
```

## 📊 Dataset

7,400 used-car listings from an Indian online car marketplace, listed between Feb 2019 and May 2021, covering 27 brands, 185 models and 13 cities. After removing duplicates and invalid prices (₹0 or a few rupees), 7,391 rows remain.

## 🔬 Approach

**1. Finding and removing target leakage.** EDA showed several columns that effectively contain the answer:

| Column | Why it had to go |
|---|---|
| `booking_down_pymnt`, `emi_starts_from` | Computed from the sale price (correlation 1.00) |
| `broker_quote` | A dealer quote for the same car (correlation 0.96) |
| `original_price` | Sale price is always 64–100% of it, so it's the listing's pre-discount price, not the new-car price. Users would enter the showroom price instead, which the model never saw. |
| `car_rating` | The site's own "great / fair / overpriced" verdict on the price |
| `times_viewed`, `is_hot`, `reserved`, `source`, … | Listing-platform details a buyer can't know for their own car |

**2. Features.** Only what a buyer or seller actually knows: make, model, variant, fuel type, transmission, body type, city, kilometers, number of owners, and **car age at the time of sale** (listing year − manufacturing year), so "age" means the same thing in training and in the app.

**3. Modelling.** All encoding happens inside a scikit-learn `Pipeline`, and the target is trained on log(price), since prices are right-skewed. Three models were compared with 5-fold cross-validation on the training set, and the winner was scored **once** on a held-out 20% test set.

## 📈 Results

5-fold cross-validation (training set):

| Model | CV R² | CV MAE |
|---|---|---|
| Ridge regression (baseline) | 0.883 | ₹49,714 |
| Random forest | 0.867 | ₹52,069 |
| **Histogram gradient boosting** | **0.890** | **₹45,295** |

Held-out test set (best model):

| R² | MAE | RMSE | MAPE |
|---|---|---|---|
| **0.929** | ₹42,652 | ₹74,551 | 10.6% |

80% of test cars sold between 0.86× and 1.15× of the prediction, and that's the range the app shows.

Most important inputs (permutation importance): model (35%), car age (30%), body type (11%), city (9%), make (7%).

## 🚀 Getting Started

```bash
git clone https://github.com/rv2363/smart-used-car-price-prediction.git
cd smart-used-car-price-prediction
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

python train.py                   # optional: retrain (~1 min), rewrites models/
python app/app.py                 # http://127.0.0.1:5000
```

### Deploying (e.g. Render)

- **Build command:** `pip install -r requirements.txt`
- **Start command:** `gunicorn --chdir app app:app`

The saved model must be loaded with the same scikit-learn version it was trained with. If you change versions in `requirements.txt`, run `python train.py` again and commit the new `models/` files.

### API

```bash
curl -X POST http://127.0.0.1:5000/predict -H "Content-Type: application/json" -d '{
  "make": "maruti", "model": "swift", "yr_mfr": 2019, "kms_run": 40000,
  "fuel_type": "petrol", "transmission": "manual", "city": "mumbai",
  "asking_price": 450000
}'
```

## ⚠️ Limitations

- Prices reflect the **2019–2021** market. Used-car prices in India rose after that, so estimates may run low for today.
- The data has no information on condition or accident history. Accident history applies a disclosed flat 15% reduction, not a learned effect.
- Brands with very few listings (Jaguar, Volvo, Kia, …) and cities outside the 13 in the data get less reliable estimates. The app warns about this.

## 🔮 Future Improvements

- Retrain on recent listings and add an inflation adjustment
- Quantile regression for per-car uncertainty ranges
- SHAP explanations for each individual prediction
- Unit tests and a GitHub Actions CI workflow

## 👤 Author

**<!-- TODO: Your Name -->** · GitHub [@rv2363](https://github.com/rv2363) · LinkedIn <!-- TODO -->
